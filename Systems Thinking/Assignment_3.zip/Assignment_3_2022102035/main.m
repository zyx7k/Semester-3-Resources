tspan = 0:0.01:40;
z0 = 1;

y0 = [0.5; z0];

% Defining the system of differential equations
ode = @(t, y) [y(1)*y(2)*(y(2) - z0); step_input(t)/y(1) - y(2)];
[t, y] = ode45(ode, tspan, y0);

y_result = y(:, 1);
z_result = y(:, 2);
x_result = arrayfun(@step_input, t);

% Plotting
figure;
plot(t, x_result, 'g', 'LineWidth', 2); % Input x(t)
hold on;
plot(t, y_result, 'b', 'LineWidth', 2); % Output y(t)
plot(t, z_result, 'r', 'LineWidth', 2); % Output z(t)
xlabel('Time');
ylabel('Concentration');
legend('x(t)', 'y(t)', 'z(t)');
title('Fold Change Detection Circuit Response for Step Input');
grid on;
hold off;

