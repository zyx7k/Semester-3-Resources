% Stepwise increasing input function
function x_val = step_input(t)
    % step function for x

    x_val = 2^floor(t/10);
end
