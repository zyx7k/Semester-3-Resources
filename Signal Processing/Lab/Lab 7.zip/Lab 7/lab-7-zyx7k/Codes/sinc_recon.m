function xr = sinc_recon(n, xn, Ts, t_fine)
    ws = 2*pi/Ts;
    wc = ws /2;

    xr = zeros(1, length(t_fine));
    for k = 1 : length(t_fine)
        for o = 1 : length(n)
            if(t_fine(k) ~= n(o))
                xr(k) = xr(k) + Ts * xn(o) * sin(wc * (t_fine(k) - n(o))) / (pi * (t_fine(k) - n(o)));
            else
                xr(k) = xr(k) + Ts * xn(o) * wc / pi;
            end
        end
    end
end
