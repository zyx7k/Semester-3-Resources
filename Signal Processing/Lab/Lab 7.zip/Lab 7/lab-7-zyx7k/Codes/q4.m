%--------(bitrates of the files)---------%

%1.wav --> 1MB, bitrate: 1411kbps 
%2.wav --> 2MB, bitrate: 1411kbps
%3.wav --> 5MB, bitrate: 1411kbps
%4.wav --> 10MB, bitrate: 1411kbps

%--------(reading the audio file)---------%

[Y1, FS1] = audioread("1.wav");
[Y2, FS2] = audioread("2.wav");
[Y3, FS3] = audioread("3.wav");
[Y4, FS4] = audioread("4.wav");

%-----(finding the length of the file)-----%

length_1 = (size(Y1,1)-1)/FS1; %in seconds
length_2 = (size(Y2,1)-1)/FS2; %in seconds
length_3 = (size(Y3,1)-1)/FS3; %in seconds
length_4 = (size(Y4,1)-1)/FS4; %in seconds

%-------(finding the bits per sample)-------%

bits_1 = round(1411*1000/FS1,0);
bits_2 = round(1411*1000/FS2,0);
bits_3 = round(1411*1000/FS3,0);
bits_4 = round(1411*1000/FS4,0);

%----(playing the audio file at different sampling rates)----%

%Using audio file 1
sound(Y1, FS1);

%Lower Sampling Rate
sound(Y1, 0.9*FS1);
sound(Y1, 0.8*FS1);
sound(Y1, 0.7*FS1);

%Higher Sampling Rate
sound(Y1, 1.2*FS1);
sound(Y1, 1.4*FS1);
sound(Y1, 1.6*FS1);


%------Displaying Values-------%
fprintf('1MB File -->\n');
fprintf('Sampling Frequency (Fs) is %d Hz\n', FS1);
fprintf('The bitrate is: 1411kbps\n');
fprintf('The length of the audio file is %.2f seconds\n', length_1);
fprintf('Number of bits used by ADC is %d\n', bits_1);
fprintf('Number of Quantization Levels is %d\n\n', 2^(bits_1));

fprintf('2MB File -->\n');
fprintf('The bitrate is: 1411kbps\n');
fprintf('Sampling Frequency (Fs) is %d Hz\n', FS2);
fprintf('The length of the audio file is %.2f seconds\n', length_2);
fprintf('Number of bits used by ADC is %d\n', bits_2);
fprintf('Number of Quantization Levels is %d\n\n', 2^(bits_2));

fprintf('5MB File -->\n');
fprintf('The bitrate is: 1411kbps\n');
fprintf('Sampling Frequency (Fs) is %d Hz\n', FS3);
fprintf('The length of the audio file is %.2f seconds\n', length_3);
fprintf('Number of bits used by ADC is %d\n', bits_3);
fprintf('Number of Quantization Levels is %d\n\n', 2^(bits_3));

fprintf('10MB File -->\n');
fprintf('The bitrate is: 1411kbps\n');
fprintf('Sampling Frequency (Fs) is %d Hz\n', FS4);
fprintf('The length of the audio file is %.2f seconds\n', length_4);
fprintf('Number of bits used by ADC is %d\n', bits_4);
fprintf('Number of Quantization Levels is %d\n\n', 2^(bits_4));

%The answer is very close to 32 bits%
%The level of quantization is 2^32 levels%

