t_fine = 0:0.001:2;
x_t = cos(5*pi*t_fine)+sin(10*pi*t_fine);

Ts = 0.1;
t_samples = 0:Ts:2;
x_t_sampled = cos(5*pi*t_samples)+sin(10*pi*t_samples);
figure(1);
plot(t_fine, x_t); grid on;
hold on;
stem(t_samples, x_t_sampled); grid on;
xlabel("Time Index [n]");
ylabel("Amplitude");
legend('Original Signal', ' Sampled Version');
title('Original Signal vs Sampled Version');
