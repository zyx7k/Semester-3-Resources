t_fine = 0:0.001:2;
x_t = cos(5*pi*t_fine)+sin(10*pi*t_fine);

%-----plotting original signal----%
figure(1);
subplot(2,2,1);
plot(t_fine, x_t); grid on;
xlabel("Time Index [n]");
ylabel("Amplitude");
title('Original Signal');

%-----getting sampled signal------%

Ts = 0.1;
t_samples = 0:Ts:2;
x_t_sampled = cos(5*pi*t_samples)+sin(10*pi*t_samples);

%-----for mae calculation------%
start_index = 0.25 / 0.001 + 1;
end_index = 1.75 / 0.001 + 1;

%-----reconstruction with various methods-----%
x_t_reconstructed_zero_hold = interp1(t_samples, x_t_sampled, t_fine, 'previous');
x_t_reconstructed_linear = interp1(t_samples, x_t_sampled, t_fine, 'linear');
xr = sinc_recon(t_samples, x_t_sampled, Ts, t_fine);


% ---- extracting signal between 0.25 to 1.75 ---- %
zero_hold_segment = x_t_reconstructed_zero_hold(start_index:end_index);
linear_segment = x_t_reconstructed_linear(start_index:end_index);
sinc_recon_segment = xr(start_index:end_index);
x_t_segment = x_t(start_index:end_index);

% ---- mae error calculation ---- %
mae_zero_hold = max(abs(x_t_segment - zero_hold_segment));
mae_linear = max(abs(x_t_segment - linear_segment));
mae_sinc_recon = max(abs(x_t_segment - sinc_recon_segment));


%----plotting----%
subplot(2,2,2);
stem(t_samples, x_t_sampled); hold on;
plot(t_fine, x_t_reconstructed_zero_hold); grid on;
xlabel("Time Index [n]");
ylabel("Amplitude");
Text = ['Mean Absolute Error (MAE): ', num2str(mae_zero_hold)];
text(1, 0.5, Text , 'FontSize', 10, 'FontWeight', 'normal', 'Color', 'red');
legend('Sampled Signal', 'Reconstructed Signal');
title('Reconstructed Signal using Zero Hold Interpolation');

%----plotting----%
subplot(2,2,3);
stem(t_samples, x_t_sampled); hold on;
plot(t_fine, x_t_reconstructed_linear); grid on;
xlabel("Time Index [n]");
ylabel("Amplitude");
Text = ['Mean Absolute Error (MAE): ', num2str(mae_linear)];
text(1, 0.5, Text , 'FontSize', 10, 'FontWeight', 'normal', 'Color', 'red');
legend('Sampled Signal', 'Reconstructed Signal');
title('Reconstructed Signal using Linear Interpolation');

%----plotting----%

subplot(2,2,4);
stem(t_samples, x_t_sampled); hold on;
plot(t_fine, xr); grid on;
xlabel("Time Index [n]");
ylabel("Amplitude");
Text = ['Mean Absolute Error (MAE): ', num2str(mae_sinc_recon)];
text(1, 0.5, Text , 'FontSize', 10, 'FontWeight', 'normal', 'Color', 'red');
legend('Sampled Signal', 'Reconstructed Signal');
title('Reconstructed Signal using Sinc');