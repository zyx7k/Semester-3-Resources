syms t;
y = piecewise(t<-1, 0, -1<=t<=1, 1-abs(t), t>1, 0);

range = -10: 0.001 : 10;
t_fine = range;
figure(1);

%i) 
Ts = 0.5;
range_1 = -10 : Ts : 10;
sample_1 = zeros(1, length(range_1));
for k  = 1: length(range_1)
    sample_1(k) = subs(y, t, range_1(k));
end
xr_1 = sinc_recon(range_1, sample_1, Ts, t_fine);

subplot(2,2,1);
plot(range_1, sample_1); hold on;
plot(t_fine, xr_1);
xlabel('Time Index [n]');
ylabel('Amplitude');
legend('Sampled Signal', 'Reconstrcuted Signal');
title('Plots for Ts = 0.5s');


%ii) 
Ts = 0.2;
range_2 = -10 : Ts : 10;
sample_2 = zeros(1, length(range_2));
for k  = 1: length(range_2)
    sample_2(k) = subs(y, t, range_2(k));
end
xr_2 = sinc_recon(range_2, sample_2, Ts, t_fine);

subplot(2,2,2);
plot(range_2, sample_2); hold on;
plot(t_fine, xr_2);
xlabel('Time Index [n]');
ylabel('Amplitude');
legend('Sampled Signal', 'Reconstrcuted Signal');
title('Plots for Ts = 0.2s');


%iii) 
Ts = 0.1;
range_3 = -10 : Ts : 10;
sample_3 = zeros(1, length(range_3));
for k  = 1: length(range_3)
    sample_3(k) = subs(y, t, range_3(k));
end
xr_3 = sinc_recon(range_3, sample_3, Ts, t_fine);

subplot(2,2,3);
plot(range_3, sample_3); hold on;
plot(t_fine, xr_3);
xlabel('Time Index [n]');
ylabel('Amplitude');
legend('Sampled Signal', 'Reconstrcuted Signal');
title('Plots for Ts = 0.1s');

%iv) 
Ts = 0.05;
range_4 = -10 : Ts : 10;
sample_4 = zeros(1, length(range_4));
for k  = 1: length(range_4)
    sample_4(k) = subs(y, t, range_4(k));
end
xr_4 = sinc_recon(range_4, sample_4, Ts, t_fine);


subplot(2,2,4);
plot(range_4, sample_4); hold on;
plot(t_fine, xr_4);
xlabel('Time Index [n]');
ylabel('Amplitude');
legend('Sampled Signal', 'Reconstrcuted Signal');
title('Plots for Ts = 0.05s');

sgtitle('Reconstruction of Non-band-limited signal');
