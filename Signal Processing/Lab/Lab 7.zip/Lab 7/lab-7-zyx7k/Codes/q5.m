t_fine = 0 : 0.001 : 2;
%Given signal is x(t) = cos(5*pi*t)
%It's frequeny is 2.5Hz
%Nyquist rate is 5Hz, i.e rate should be higher than 5Hz or Ts < 0.2s

syms t;
x_t = cos(5*pi*t);
figure(1);

% i)
Ts = 0.1;
range_1 = 0 : Ts : 2;
sample_1 = zeros(1, length(range_1));
for k  = 1: length(range_1)
    sample_1(k) = subs(x_t, t, range_1(k));
end
xr_1 = sinc_recon(range_1, sample_1, Ts, t_fine);

subplot(2,2,1);
stem(range_1, sample_1); hold on;
plot(t_fine, xr_1);
xlabel('Time Index [n]');
ylabel('Amplitude');
legend('Sampled Signal', 'Reconstrcuted Signal');
title('Plots for Ts = 0.1s');


% ii)
Ts = 0.2;
range_2 = 0 : Ts : 2;
sample_2 = zeros(1, length(range_2));
for k  = 1: length(range_2)
    sample_2(k) = subs(x_t, t, range_2(k));
end
xr_2 = sinc_recon(range_2, sample_2, Ts, t_fine);

subplot(2,2,2);
stem(range_2, sample_2); hold on;
plot(t_fine, xr_2);
xlabel('Time Index [n]');
ylabel('Amplitude');
legend('Sampled Signal', 'Reconstrcuted Signal');
title('Plots for Ts = 0.2s');


% iii)
Ts = 0.3;
range_3 = 0 : Ts : 2;
sample_3 = zeros(1, length(range_3));
for k  = 1: length(range_3)
    sample_3(k) = subs(x_t, t, range_3(k));
end
xr_3 = sinc_recon(range_3, sample_3, Ts, t_fine);

subplot(2,2,3);
stem(range_3, sample_3); hold on;
plot(t_fine, xr_3);
xlabel('Time Index [n]');
ylabel('Amplitude');
legend('Sampled Signal', 'Reconstrcuted Signal');
title('Plots for Ts = 0.3s');

% iv)
Ts = 0.4;
range_4 = 0 : Ts : 2;
sample_4 = zeros(1, length(range_4));
for k  = 1: length(range_4)
    sample_4(k) = subs(x_t, t, range_4(k));
end
xr_4 = sinc_recon(range_4, sample_4, Ts, t_fine);

subplot(2,2,4);
stem(range_4, sample_4); hold on;
plot(t_fine, xr_4);
xlabel('Time Index [n]');
ylabel('Amplitude');
legend('Sampled Signal', 'Reconstrcuted Signal');
title('Plots for Ts = 0.4s');

sgtitle('Demonstrating Aliasing');