w0 = 1;
j = sqrt(-1);
T = 2*pi;
t = -2*T:0.01:2*T;
xt = cos(2*t)+sin(3*t);
wc = 2.5;
N = 3;
A = [1/2 j*(1/2) 0 0 0 -j*(1/2) 1/2];
B= myLPF(A,w0,wc);
time_grid = -2*T:0.01:2*T;
recons_A = partial_fouriersum(A,T,time_grid);
recons_B = partial_fouriersum(B,T,time_grid);


figure;
subplot(2,2,1);
plot(time_grid, recons_A);
title('Input Signals');
xlabel('t');
ylabel('recons{A(t)}');
grid on;
subplot(2,2,2);
plot(time_grid, recons_B);
title('Output Signals[LPF]');
xlabel('t');
ylabel('recons{B(t)}');
grid on;

B= myHPF(A,w0,wc);
time_grid = -2*T:0.01:2*T;
% recons_A = partial_fouriersum(A,T,time_grid);
recons_B = partial_fouriersum(B,T,time_grid);
subplot(2,2,3);
plot(time_grid, real(recons_B));
title('Output Signals[HPF]');
xlabel('t');
ylabel('recons{B(t)}');
grid on;

B= NonIdeal(A,w0,1,1);
time_grid = -2*T:0.01:2*T;
% recons_A = partial_fouriersum(A,T,time_grid);
recons_B = partial_fouriersum(B,T,time_grid);
subplot(2,2,4);
plot(time_grid, recons_B);
title('Output Signals[NON IDEAL]');
xlabel('t');
ylabel('recons{B(t)}');
grid on;

% 
% subplot(2,1,3);
% plot(time_grid, imag(recons_B));
% title('Reconstructed Output Signals[wc = 2.5]');
% xlabel('t');
% ylabel('recons{B(t})');
% grid on;
% sgtitle('LPF');
% 
% 
% B= myHPF(A,w0,wc);
% time_grid = -2*T:0.01:2*T;
% recons_A = partial_fouriersum(A,T,time_grid);
% recons_B = partial_fouriersum(B,T,time_grid);
% figure;
% subplot(3,1,1);
% plot(time_grid, recons_A);
% title('Reconstructed Input Signals');
% xlabel('t');
% ylabel('recons{A(t)}');
% grid on;
% subplot(3,1,2);
% plot(time_grid, real(recons_B));
% title('Reconstructed Output Signals[wc = 2.5]');
% xlabel('t');
% ylabel('recons{B(t)}');
% grid on;
% subplot(3,1,3);
% plot(time_grid, imag(recons_B));
% title('Reconstructed Output Signals[wc = 2.5]');
% xlabel('t');
% ylabel('recons{B(t)}');
% grid on;
% sgtitle('HPF');
% 
% 
% B= NonIdeal(A,w0,1,1);
% time_grid = -2*T:0.01:2*T;
% recons_A = partial_fouriersum(A,T,time_grid);
% recons_B = partial_fouriersum(B,T,time_grid);
% figure;
% subplot(3,1,1);
% plot(time_grid, recons_A);
% title('Reconstructed Input Signals');
% xlabel('t');
% ylabel('recons{A(t)}');
% grid on;
% subplot(3,1,2);
% plot(time_grid, recons_B);
% title('Reconstructed Output Signals[wc = 2.5]');
% xlabel('t');
% ylabel('recons{B(t)}');
% grid on;
% subplot(3,1,3);
% plot(time_grid, imag(recons_B));
% title('Reconstructed Output Signals[wc = 2.5]');
% xlabel('t');
% ylabel('recons{B(t)}');
% grid on;
% sgtitle('Non-Ideal');
% 
