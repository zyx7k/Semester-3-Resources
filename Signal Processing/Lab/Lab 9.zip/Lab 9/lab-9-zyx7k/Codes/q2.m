%--------Part A---------%

N = 51;
nc = (N-1)/2;
wc = pi/6;
n = 0:1:50;

hdn_1 = sin(wc*(n-nc))./(pi*(n-nc)); % You can get hdn from Hd(w) by inverse DTFT
hdn_1(nc+1) = 1/6; % Because It wasn't defined at this point previously because limits
wn_1 = ones(1, N);

hn_1 = wn_1 .* hdn_1;

%--------Part B---------%
Hw_1 = fft(hn_1, 1001); %1001 point DFT
Hw_new1 = mag2db(abs(Hw_1));

figure(1);
subplot(3,1,1);
stem(n, hn_1);
xlabel('Sample Index');
ylabel('Amplitude');
title('Filter coefficients h[n]');

subplot(3,1,2);
plot(Hw_new1);
ylim([-100,10]);
xlim([0, 1001]);
xlabel('w');
ylabel('Magnitude in dB');
title('DFT Magitude');

subplot(3,1,3);
plot(angle(Hw_1));
xlim([0, 1001]);
xlabel('w');
ylabel('Phase');
title('DFT Phase');

sgtitle('h[n] and its DFT for a Rectangular Window');

%--------Part C---------%

hdn_2 = sin(wc*(n-nc))./(pi*(n-nc)); % You can get hdn from Hd(w) by inverse DTFT
hdn_2(nc+1) = 1/6; % Because It wasn't defined at this point previously because limits
wn_2 = transpose(blackman(N));
hn_2 = hdn_2 .* wn_2;

Hw_2 = fft(hn_2, 1001); %1001 point DFT
Hw_new2 = mag2db(abs(Hw_2));

figure(2);
subplot(3,1,1);
plot(n, hn_2);
xlabel('Sample Index');
ylabel('Amplitude');
title('Filter coefficients h[n] for Blackman Window');

subplot(3,1,2);
plot(Hw_new2);
ylim([-100,10]);
xlim([0, 1001]);
xlabel('w');
ylabel('Magnitude in dB');
title('DFT Magitude (Blackman Window)');

subplot(3,1,3);
plot(angle(Hw_2));
xlim([0, 1001]);
xlabel('w');
ylabel('Phase');
title('DFT Phase');

sgtitle('h[n] and its DFT for a Blackman Window');

%--------Part E---------%
n_new = 0:1:200;
xn = cos(pi/16*n_new) + 0.25*sin(pi/16*n_new);
yn_1 = conv(xn, hn_1);
yn_2 = conv(xn, hn_2);
n_new_2 = 0:1:length(yn_1)-1;

figure(3);
subplot(3,1,1);
plot(n_new, xn);
xlabel('Sample Index');
ylabel('Amplitude');
title('Original Signal');

subplot(3,1,2);
plot(n_new_2, yn_1);
xlabel('Sample Index');
ylabel('Amplitude');
title('Filtered Signal by Rectangular Window');

subplot(3,1,3);
plot(n_new_2, yn_2);
xlabel('Sample Index');
ylabel('Amplitude');
title('Filtered Signal by Blackman Window');

%--------Part E (ii)---------%
n_new = 0:1:200;
xn_1 = cos(pi/16*n_new) + 0.25*randn(1,201);
yn_3 = conv(xn, hn_1);
yn_4 = conv(xn, hn_2);
n_new_3 = 0:1:length(yn_3)-1;

figure(4);
subplot(3,1,1);
plot(n_new, xn_1);
xlabel('Sample Index');
ylabel('Amplitude');
title('Original Signal');

subplot(3,1,2);
plot(n_new_3, yn_3);
xlabel('Sample Index');
ylabel('Amplitude');
title('Filtered Signal by Rectangular Window');

subplot(3,1,3);
plot(n_new_3, yn_4);
xlabel('Sample Index');
ylabel('Amplitude');
title('Filtered Signal by Blackman Window');

%--------Part F---------%
h1n = ((-1).^n).*hn_1;

H1w = fft(h1n, 1001); %1001 point DFT
H1w_new = mag2db(abs(H1w));

figure(5);
subplot(3,1,1);
plot(n, h1n);
xlabel('Sample Index');
ylabel('Amplitude');
title('Filter coefficients h1[n]');

subplot(3,1,2);
plot(H1w_new);
ylim([-100,10]);
xlim([0, 1001]);
xlabel('w');
ylabel('Magnitude in dB');
title('DFT Magitude');

subplot(3,1,3);
plot(angle(H1w));
xlim([0, 1001]);
xlabel('w');
ylabel('Phase');
title('DFT Phase');

sgtitle('h1[n] and its DFT for a Rectangular Window');

