function B = NonIdeal(A, w0_FS, G, a)
    N = (length(A) - 1)/2; 
    B = zeros(2*N + 1, 1); 
    for k = -N:N
        w_k = k * w0_FS;
         H = G/(1i*w_k+a);
         B(k+N+1) = H*A(k+N+1);
    end
end
