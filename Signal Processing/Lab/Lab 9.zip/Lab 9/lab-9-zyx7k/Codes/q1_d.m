w0 = 1;
T = 2*pi;
t = -2*T:0.01:2*T;
xt = cos(t);
wc = 0.5;
N = 1;
% A = zeros(2*N+1,1);
A = [1/2 0 1/2];
B= NonIdeal(A,w0,1,1);
time_grid = -2*T:0.01:2*T;
recons_A = partial_fouriersum(A,T,time_grid);
recons_B = partial_fouriersum(B,T,time_grid);

figure;
subplot(2,1,1);
plot(time_grid, recons_A);
title('Reconstructed Input Signals');
xlabel('t');
ylabel('recons{A(t)}');
grid on;

subplot(2,1,2);
plot(time_grid, recons_B);
title('Reconstructed Output Signals[wc = 0.5]');
xlabel('t');
ylabel('recons{B(t)}');
grid on;