function y = partial_fouriersum (A, T, time_grid)
Num = (length(A)-1)/2;
y = zeros(size(time_grid));
for k = -Num:Num
 y = y + A(k+Num+1)*exp(1j*time_grid*((2*pi*k)/T));
end
end