%-------(part (a))------------%

b0_1 = (2+sqrt(2))/2; %by mamual calculation
w0 = pi /4;
b_1 = [b0_1, -2*cos(w0)*b0_1, b0_1];
a_1 = [1];

figure(1);
freqz(b_1, a_1, 2001);
sgtitle('FIR Filter');

%fvtool(b_1, a_1);

%-------(part (b))-----------%

r0_1 = 0.9;
b0_2 = ((1+r0_1^2-sqrt(2)*r0_1))/(2-sqrt(2)); %by mamual calculation
w0 = pi /4;
b_2 = [b0_2, -2*cos(w0)*b0_2, b0_2];
a_2 = [1, -2*cos(w0)*r0_1, r0_1^2];

figure(2);
freqz(b_2, a_2, 2001);
sgtitle('IIR Filter');

%fvtool(b_2, a_2);

%----------(part (d))------%

r0_2 = 0.5;
b0_3 = ((1+r0_2^2-sqrt(2)*r0_2))/(2-sqrt(2)); %by mamual calculation
b_3 = [b0_3, -2*cos(w0)*b0_3, b0_3];
a_3 = [1, -2*cos(w0)*r0_2, r0_2^2];

freqz(b_3, a_3, 2001);
%fvtool(b_3, a_3);
sgtitle('Visualization for r0 = 0.5');

%----------(part (d) ii)------%

r0_3 = 0.99;
b0_4 = ((1+r0_3^2-sqrt(2)*r0_3))/(2-sqrt(2)); %by mamual calculation
b_4 = [b0_4, -2*cos(w0)*b0_4, b0_4];
a_4 = [1, -2*cos(w0)*r0_3, r0_3^2];

freqz(b_4, a_4, 2001);
%fvtool(b_4, a_4);
sgtitle('Visualization for r0 = 0.99');

%----------(part (e))------%
sound = load('handel.mat');
xn = sound.y;
Fs = sound.Fs;

f0 = 1024;

time_index = 0: 1/Fs:(length(xn)-1)/Fs;
noise = sin(2*pi*f0*time_index);
x = xn + transpose(noise);

pause(5);
sound(x);
pause(5);

y1 = filter(b_1, a_1, x); %FIR Filter
y2 = filter(b_2, a_2, x); %IIR Filter

sound(y1);
pause(5);
sound(y2);

%--------------part(e)--------------%
index = 1: 100;

input_1 = xn(1:100);
input_2 = x(1:100);
output_1 = y1(1:100);
output_2 = y2(1:100);

figure(3);
subplot(2,2,1)
plot(input_1);
grid on
xlabel('Sample Index');
ylabel('Amplitude');
title('Original Signal');

subplot(2,2,2)
plot(input_2);
grid on
xlabel('Sample Index');
ylabel('Amplitude');
title('Signal sent to filter');

subplot(2,2,3)
plot(output_1);
grid on
xlabel('Sample Index');
ylabel('Amplitude');
title('FIR Filter Output');

subplot(2,2,4)
plot(output_2);
xlabel('Sample Index');
ylabel('Amplitude');
title('IIR Filter Output with r0=0.9');

grid on;
sgtitle('Notch Filter (w0 = \pi/4 and r_0 = 0.9)');


