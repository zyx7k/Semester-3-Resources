p = 0.8; %pole location
b = [1];          % Coefficients of the numerator polynomial
a = [1, p];     % Coefficients of the denominator polynomial

% Create the pole-zero plot
zplane(b, a);

title('Pole-Zero Plot');
xlabel('Real');
ylabel('Imaginary');
axis([-2 2 -2 2]);
grid on;
