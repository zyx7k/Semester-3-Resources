p = 0.8; %pole location
b = [1];          % Coefficients of the numerator polynomial
a = [1, p];     % Coefficients of the denominator polynomial

[h,w]=freqz(b,a,1001, 'whole');

figure;
plot(w, abs(h));
xlim([0,2*pi]);
xticks([0 pi/2 pi 3*pi/2 2*pi]);
xticklabels({'0', '\pi/2', '\pi', '3\pi/2', '2\pi'});
title("Magnitude Response")
xlabel('Frequency (\omega)')
ylabel('Magntiude')
