b=1;
a=[1, -0.8];
n=1001;

figure(1);
zplane(b, a);
title('Pole-Zero Plot for p = -0.8');
xlabel('Real');
ylabel('Imaginary');
axis([-2 2 -2 2]);
grid on;
%--------------%
figure(2);
[h,t]=impz(b,a);
stem(t,h);
title("Impulse Response for p = -0.8");
xlabel("Time (t)");
ylabel("Amplitude");
%--------------%
figure(3);
[h,w]=freqz(b,a,n,'whole');
plot(w,abs(h));
xlim([0,2*pi]);
xticks([0 pi/2 pi 3*pi/2 2*pi]);
xticklabels({'0', '\pi/2', '\pi', '3\pi/2', '2\pi'});
title("Magnitude Response for p = -0.8")
xlabel('Frequency (\omega)')
ylabel('Magntiude')

%-----------------------%
a=[1, 0.1];

figure(4);
zplane(b, a);
title('Pole-Zero Plot for p = -0.8');
xlabel('Real');
ylabel('Imaginary');
axis([-2 2 -2 2]);
grid on;
%--------------%
figure(5);
[h,t]=impz(b,a);
stem(t,h);
title("Impulse Response for p = 0.1");
xlabel("Time (t)");
ylabel("Amplitude");
%--------------%
figure(6);
[h,w]=freqz(b,a,n,'whole');
plot(w,abs(h));
xlim([0,2*pi]);
xticks([0 pi/2 pi 3*pi/2 2*pi]);
xticklabels({'0', '\pi/2', '\pi', '3\pi/2', '2\pi'});
title("Magnitude Response for p = 0.1")
xlabel('Frequency (\omega)')
ylabel('Magntiude')