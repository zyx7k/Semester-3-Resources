b=1;
a=[1, 0.8];
[h,t]=impz(b,a);

figure;
stem(t,h);
title("Impulse Response");
xlabel("Time (t)");
ylabel("Amplitude");