r = 0.95;
theta = [0 , pi/4, pi/2, 3*pi/4, pi];

for k = 1 : 5
    figure(k);
    b = [1,-2*cos(theta(k)), 1];
    a = [1, -2*r*cos(theta(k)), r*r];
    [h,w]=freqz(b,a,1001, 'whole');
    plot(w, abs(h));
    xlim([0,2*pi]);
    xticks([0 pi/2 pi 3*pi/2 2*pi]);
    xticklabels({'0', '\pi/2', '\pi', '3\pi/2', '2\pi'});
    xlabel('Frequency (\omega)')
    ylabel('Magntiude')
    title(['Magnitude Response for r = ', num2str(r), ' and theta = ', num2str(theta(k))]);
end
