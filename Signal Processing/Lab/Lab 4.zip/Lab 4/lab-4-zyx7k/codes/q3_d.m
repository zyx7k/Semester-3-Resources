r = [0.1, 0.3, 0.5, 0.7, 0.9];
theta = pi/3;

for k = 1 : 5
    figure(k);
    b = [1,-2*cos(theta), 1];
    a = [1, -2*r(k)*cos(theta), r(k)*r(k)];
    [h,w]=freqz(b,a,1001, 'whole');
    plot(w, abs(h));
    xlim([0,2*pi]);
    xticks([0 pi/2 pi 3*pi/2 2*pi]);
    xticklabels({'0', '\pi/2', '\pi', '3\pi/2', '2\pi'});
    xlabel('Frequency (\omega)')
    ylabel('Magntiude')
    title(['Magnitude Response for r = ', num2str(r(k)), ' and theta = ', num2str(theta)]);
end
