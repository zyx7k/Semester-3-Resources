r = [0.1, 0.2, 0.4, 0.6, 0.8];
theta = [0 , pi/4, pi/2, 3*pi/4, pi];

for k = 1 : 5
    figure(k);
    b = [1,-2*cos(theta(k)), 1];
    a = [1, -2*r(k)*cos(theta(k)), (r(k)*r(k))];
    zplane(b,a);
    title(['Plot for r = ', num2str(r(k)), ' and theta = ', num2str(theta(k))]);
end
