b = [1];          % Coefficients of the numerator polynomial
a = [1, -0.5, 0.2, -0.1, 0.007, 0.14, 0.15];     % Coefficients of the denominator polynomial

figure(1);
[h,w]=freqz(b, a,10000, 'whole');
plot(w, abs(h));
xlim([0,2*pi]);
xticks([0 pi/2 pi 3*pi/2 2*pi]);
xticklabels({'0', '\pi/2', '\pi', '3\pi/2', '2\pi'});
title("Magnitude Response")
xlabel('Frequency (\omega)')
ylabel('Magntiude')

figure(2);
zplane(b, a);
grid("on")