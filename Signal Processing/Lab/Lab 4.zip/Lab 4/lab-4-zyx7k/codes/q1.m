p = {[3 + 0j],[0.1 + 0j], [0+0j], [0+0j, 0.5 + 0j], [2+0j, -0.5+0j], [0.5+0j, -0.5+0j],[2+0j,2+0j,2+0j], [0+0j,1+0j,2+0j], [-0.5+0j, 0+1j], [0+0j, 0+1j, 0-1j], [0.5+0j, -0.5+0j, 2+1j, 2-1j], [1+1j, 1+2j, 1+3j, 2+1j]};

for k = 1 : length(p)
    [N, ROC, C, S] = roc_cs(p{k});

    fprintf('The Pole(s) are:\n')
    display((p{k}));
    fprintf('Numer of ROC = %d', N);
    display(ROC);
    display(C);
    display(S);
    fprintf('------------------------\n\n\n');
end

