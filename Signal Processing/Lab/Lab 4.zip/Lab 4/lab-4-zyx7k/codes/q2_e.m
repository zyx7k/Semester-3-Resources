p=0.5;
b=[1, -p^-1];
a=[1, -p];
n=1001;

figure(1);
zplane(b, a);
title('Pole-Zero Plot for p = -0.8');
xlabel('Real');
ylabel('Imaginary');
axis([-1.5 2.5 -1.5 1.5]);
grid on;
%--------------%
figure(2);
[h,t]=impz(b,a);
stem(t,h);
title("Impulse Response for p = -0.8");
xlabel("Time (t)");
ylabel("Amplitude");
%--------------%
figure(3);
[h,w]=freqz(b,a,n,'whole');
plot(w,abs(h));
xlim([0,2*pi]);
xticks([0 pi/2 pi 3*pi/2 2*pi]);
xticklabels({'0', '\pi/2', '\pi', '3\pi/2', '2\pi'});
title("Magnitude Response for p = -0.8")
xlabel('Frequency (\omega)')
ylabel('Magntiude')