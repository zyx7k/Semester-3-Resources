function [N, ROC, C, S] = roc_cs(p) % p is a complex array
    
    %Firstly let's find the number of ROCS i.e. N

    length_of_p = length(p);
    magntiude_array_non_unique = zeros(1, length_of_p);

    for k  =1 : length_of_p
        magnitude = sqrt(real(p(k))^2 + imag(p(k))^2);
        magntiude_array_non_unique(k) = magnitude;
    end

    magntiude_array_unique = unique(magntiude_array_non_unique);
    
    number_of_magnitude = length(magntiude_array_unique);
    magntiude_array_unique = sort(magntiude_array_unique);

    if(magntiude_array_unique(1) == 0)
        N = number_of_magnitude;
    else
        N = number_of_magnitude+1;
    end

    ROC = zeros(N,2);
    C = zeros(1, N);
    C(N)=1; %Because causual region is always outermost 
    S = zeros(1, N);

    ROC(1,1) = 0;
    ROC(N,2) = Inf;

    if(magntiude_array_unique(1)==0)
        for k = 2: N
              ROC(k-1, 2) = magntiude_array_unique(k);
              ROC(k, 1) = magntiude_array_unique(k);
        end
    else
        for k = 1: N-1
              ROC(k, 2) = magntiude_array_unique(k);
              ROC(k+1, 1) = magntiude_array_unique(k);
        end
    end

    %Now we have to find S
    for k = 1: N
        if(ROC(k,2)>=1 && ROC(k,1)<=1)
            S(k)=1;
        end
    end
end
