clear all;
close all;

f0 = 12;
fs = 64;
L = 16;
time_index = 0 : L-1;
p_n = zeros(1, L);
for o = 1 : L
       p_n(o) = cos(2*pi*f0*time_index(o)/fs);
end
w_n = ones(1,L);
x_n = p_n .* w_n;

figure(1);
m = [1, 2, 4, 8];

for k = 1:4
    number_of_samples = L * m(k);
    x_n_fft = fft(x_n, number_of_samples);
    x_n_fft_magnitude = abs(x_n_fft);
    frequencies = (0:number_of_samples-1) * fs / number_of_samples;
    
    subplot(2,2,k);
    if(k==1 || k==2)
        stem(frequencies, x_n_fft_magnitude);
    else
        plot(frequencies, x_n_fft_magnitude);
    end
    xlabel('Frequency (Hz)');
    ylabel('Magnitude');
    title(['Magnitude of DFT for m = ', num2str(m(k))]);
end

sgtitle('DFT for various values of m and f0=12Hz');