clear all;
close all;

f0 = 12;
fs = 64;
figure(1);
L = [16, 32, 64, 128];

for k = 1:4
    time_index = 0 : L(k)-1;
    p_n = zeros(1, L(k));
    for o = 1 : L(k)
        p_n(o) = cos(2*pi*f0*time_index(o)/fs);
    end
    w_n = ones(1,L(k));
    x_n = p_n .* w_n;

    number_of_samples = 8 * L(k);
    x_n_fft = fft(x_n, number_of_samples);
    x_n_fft_magnitude = abs(x_n_fft);
    frequencies = (0:number_of_samples-1) * fs / number_of_samples;
    
    subplot(2,2,k);
    plot(frequencies, x_n_fft_magnitude);
    xlabel('Frequency (Hz)');
    ylabel('Magnitude');
    title(['Magnitude of DFT for L = ', num2str(L(k))]);
end

sgtitle('DFT for various values of L and f0=12Hz');