%------------part(a)------------%
L=4;
%-------N=4-------%
N=4;
x1_n = ones(1, L);
x2_n = zeros(1, N-L);
x_n = [x1_n, x2_n];
x_n_dft = fft(x_n);

figure(1);
subplot(3,1,1);
grid on;
stem(real(x_n_dft));
hold on;
stem(imag(x_n_dft));
xlabel('Time Index [n]');
ylabel('Amplitude');
title('DFT Sequence');
legend('real', 'imag');

subplot(3,1,2);
stem(abs(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Magnitude of DFT');

subplot(3,1,3);
stem(angle(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Phase');
title('Phase of DFT');

sgtitle('DFT Sequence for [ones(L,1); zeros(N-L,1)], N = 4');

%-------N=16-------%
N=16;
x1_n = ones(1, L);
x2_n = zeros(1, N-L);
x_n = [x1_n, x2_n];
x_n_dft = fft(x_n);

figure(2);
subplot(3,1,1);
grid on;
stem(real(x_n_dft));
hold on;
stem(imag(x_n_dft));
xlabel('Time Index [n]');
ylabel('Amplitude');
title('DFT Sequence');
legend('real', 'imag');

subplot(3,1,2);
stem(abs(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Magnitude of DFT');

subplot(3,1,3);
stem(angle(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Phase');
title('Phase of DFT');
sgtitle('DFT Sequence for [ones(L,1); zeros(N-L,1)], N = 16');
%-------N=64-------%
N=64;
x1_n = ones(1, L);
x2_n = zeros(1, N-L);
x_n = [x1_n, x2_n];
x_n_dft = fft(x_n);

figure(3);
subplot(3,1,1);
grid on;
stem(real(x_n_dft));
hold on;
stem(imag(x_n_dft));
xlabel('Time Index [n]');
ylabel('Amplitude');
title('DFT Sequence');
legend('real', 'imag');

subplot(3,1,2);
stem(abs(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Magnitude of DFT');

subplot(3,1,3);
stem(angle(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Phase');
title('Phase of DFT');
sgtitle('DFT Sequence for [ones(L,1); zeros(N-L,1)], N = 64');
%------------part(b)------------%
x_n = zeros(1, 20);
wo = 3*pi/10;
for k = 0: 19
    x_n(k+1) = sin(wo * k);
end
x_n_dft = fft(x_n);

figure(4);
subplot(3,1,1);
grid on;
stem(real(x_n_dft));
hold on;
stem(imag(x_n_dft));
xlabel('Time Index [n]');
ylabel('Amplitude');
title('DFT Sequence');
legend('real', 'imag');

subplot(3,1,2);
stem(abs(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Magnitude of DFT');

subplot(3,1,3);
stem(angle(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Phase');
title('Phase of DFT');
sgtitle('DFT Sequence for sin(w0n)');


%------------part(c)------------%
for k = 0: 19
    x_n(k+1) = cos(wo * k);
end
x_n_dft = fft(x_n);

figure(5);
subplot(3,1,1);
grid on;
stem(real(x_n_dft));
hold on;
stem(imag(x_n_dft));
xlabel('Time Index [n]');
ylabel('Amplitude');
title('DFT Sequence');
legend('real', 'imag');

subplot(3,1,2);
stem(abs(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Magnitude of DFT');

subplot(3,1,3);
stem(angle(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Phase');
title('Phase of DFT');
sgtitle('DFT Sequence for cos(w0n)');

%------------part(d)------------%
for k = 0: 19
    x_n(k+1) = sin(wo * (k-1));
end
x_n_dft = fft(x_n);

figure(6);
subplot(3,1,1);
grid on;
stem(real(x_n_dft));
hold on;
stem(imag(x_n_dft));
xlabel('Time Index [n]');
ylabel('Amplitude');
title('DFT Sequence');
legend('real', 'imag');

subplot(3,1,2);
stem(abs(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Magnitude of DFT');

subplot(3,1,3);
stem(angle(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Phase');
title('Phase of DFT');
sgtitle('DFT Sequence for sin(w0(n-1))');


%------------part(e)------------%
for k = 0: 19
    x_n(k+1) = (0.8)^k;
end
x_n_dft = fft(x_n);

figure(7);
subplot(3,1,1);
grid on;
stem(real(x_n_dft));
hold on;
stem(imag(x_n_dft));
xlabel('Time Index [n]');
ylabel('Amplitude');
title('DFT Sequence');
legend('real', 'imag');

subplot(3,1,2);
stem(abs(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Magnitude of DFT');

subplot(3,1,3);
stem(angle(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Phase');
title('Phase of DFT');
sgtitle('DFT Sequence for (0.8)^n');

%------------part(f)------------%
for k = 0: 19
    x_n(k+1) = (-0.8)^k;
end
x_n_dft = fft(x_n);

figure(8);
subplot(3,1,1);
grid on;
stem(real(x_n_dft));
hold on;
stem(imag(x_n_dft));
xlabel('Time Index [n]');
ylabel('Amplitude');
title('DFT Sequence');
legend('real', 'imag');

subplot(3,1,2);
stem(abs(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Magnitude of DFT');

subplot(3,1,3);
stem(angle(x_n_dft)); grid on;
xlabel('Time Index [n]');
ylabel('Phase');
title('Phase of DFT');
sgtitle('DFT Sequence for (-0.8)^n');