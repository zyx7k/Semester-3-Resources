x1_n = randn(1,10);
x2_n = zeros(1,10);
x2_n(4) = 1;

%---------------------part(a and b)--------------%

time_index = 0:9;
time_index_new = 0: 18;

linear_conv = conv(x1_n, x2_n, 'full');
circular_conv = cconv(x1_n, x2_n, 10);

%---------------------part(c and d)--------------%

x1_n_fft = fft(x1_n);
x2_n_fft = fft(x2_n);

circular_conv_dft = ifft(x1_n_fft .* x2_n_fft);

x1_n= [x1_n, zeros(1,9)];
x2_n = [x2_n, zeros(1,9)];
x1_n_fft = fft(x1_n);
x2_n_fft = fft(x2_n);

linear_conv_dft = ifft(x1_n_fft .* x2_n_fft);

%---------------------plotting--------------%

figure(2);
subplot(2,2,1);
plot(time_index_new, linear_conv); grid on;
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Linear Convolution using "conv" ');

subplot(2,2,2);
plot(time_index, circular_conv); grid on;
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Circular Convolution using "cconv" ');

subplot(2,2,3);
plot(time_index_new, linear_conv_dft); grid on;
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Linear Convolution using DFT');

subplot(2,2,4);
plot(time_index, circular_conv_dft); grid on;
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Circular Convolution using DFT');
sgtitle('Convolution using various methods');


