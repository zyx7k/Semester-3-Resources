N = 5;
td = 1;
fs = 10000;
P = zeros(1, N);
f0 = 50;

A = zeros(1,N);
for k = 1 :5
    A(k) = 1/k;
end
xn = harmonics(A, f0, P, td, fs);


[t_env, env] = envelope(0.2, 0.2, 0.7, 0.4, 0.2, fs);

soundsc(xn, fs); %Playing without Envelope
pause(2);
soundsc(xn.*env, fs);

figure(1);
subplot(3,1,1);
plot(xn);
xlabel('Sample Index');
ylabel('Amplitude');
title("Input Signal");
grid on;

subplot(3,1,2);
plot(t_env, env);
xlabel('Sample Index');
ylabel('Amplitude');
grid on;
title("ADSR curve");

subplot(3,1,3);
plot(t_env, xn.*env);
xlabel('Sample Index');
ylabel('Amplitude');
grid on;
title("Enveloped Signal");

sgtitle('Effects of applying ASDR Envelope')