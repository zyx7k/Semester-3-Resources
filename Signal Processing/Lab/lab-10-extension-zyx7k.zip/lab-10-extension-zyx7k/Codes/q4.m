N = 5;
P = zeros(1, N);
fs = 10000;
adsr = [0.2, 0.2, 0.7, 0.4, 0.2];

%-----part(a)------%

F_notes = 50:5:100;
A = zeros(1, N);
for k = 1 : N
    A(k) = (1/k)^2;
end
td_notes = ones(1, length(F_notes));
yn_1 = my_synthesizer(A, F_notes, P, adsr, td_notes, fs);
% soundsc(yn_1);

%-----part(b)------%

F_notes = 100:-10:40;
A = zeros(1, N);
for k = 1 : N
    A(k) = (1/k)^2;
end
td_notes = ones(1, length(F_notes));
yn_2 = my_synthesizer(A, F_notes, P, adsr, td_notes, fs);
% soundsc(yn_2);

%-----part(c)------%
 
M = 5;
N = 5;
F_notes = 50+50*rand(1,M);
td_notes = 0.5 + round(rand(1,M),2);
A = zeros(1, N);
for k = 1 : N
    A(k) = (1/k)^2;
end
yn_3 = my_synthesizer(A, F_notes, P, adsr, td_notes, fs);
% soundsc(yn_3);

%-----part(d)------%
 
% M = 10;
% N = 5;
% F_notes = 50+50*rand(1,M);
% td_notes = 0.5 + round(rand(1,M),2);
% A = zeros(1, N);
% for k = 1 : N
%     A(k) = (k+1)/(k^2);
% end
% yn_4 = my_synthesizer(A, F_notes, P, adsr, td_notes, fs);
% audiowrite('my_sound.wav', yn_4, fs);

N = 5;
array = zeros(1, N);
for k = 1:N
    array(k) = 1;
end

P = zeros(1, N);
fs = 10000;

D_5 = 622.25; D5 = 587.33; C5 = 523.25; F5 = 698.46; A_5 = 932.33; G_5 = 830.61; G5 = 783.99;
 
F_notes1 =[D_5 D_5 D5 D5 D_5 D_5 C5 C5 D_5 D_5 D5 D5 F5 F5 D_5 D_5];
F_notes2 =[C5 C5 D_5 D_5 A_5 A_5 G_5 G_5 G5 G5 G5 G5];

F_notes = [F_notes1, F_notes1, F_notes1, F_notes2, F_notes1, F_notes1, F_notes1];

td_notes = 0.2*ones(1, length(F_notes));

adsr = [0.2 0.2 0.7 0.4 0.2];

Y = my_synthesizer(array, F_notes, P, adsr, td_notes, fs);
soundsc(Y);
audiowrite('generated_audio.wav',Y,fs);