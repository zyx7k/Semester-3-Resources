function [t_env, env] = envelope(a, d, s, sd, r, fs)    
    %a – attack duration in seconds
    %d – decay duration in seconds
    %s – sustain level in [0,1]
    %sd – sustain duration in seconds   
    %r – release duration in seconds   
    %fs – sampling frequency in Hz

    %t_env – time vector sampled at fs Hz of length a+d+sd+r seconds
    %env – the corresponding ADSR envelope.
    
    % For each portion of the note, determine the corresponding piece of time vector and envelope.
    % Attack: amplitude linearly increases from 0 to 1 in ‘a’ seconds
    t_attack = 0:1/fs:a;
    env = t_attack/a;
    t_env = t_attack;

    % Decay: amplitude linearly decreases from 1 to ‘s’ in ‘d’ seconds
    t_decay = a+(1/fs):1/fs:a+d; 
    t_env = [t_env, t_decay];

    N2 = length(t_decay);
    temp1 = ones(1, N2);
    temp2 = a * temp1;

    env2 = (s-1)/d*(t_decay-temp2)+temp1;
    env = [env, env2];

    % Sustain: amplitude stays at ‘s’ for ‘sd’ seconds
    t_sustain = (a+d+(1/fs)):1/fs:a+d+sd;
    
    env3 = s*ones(1, length(t_sustain));
    t_env = [t_env, t_sustain];
    env = [env, env3];

    % Release: amplitude linearly decreases from ‘s’ to 0 in ‘r’ seconds
    t_release = (a+d+sd+(1/fs)):1/fs:a+d+sd+r;
    t_env = [t_env, t_release];

    env4 = -s/r*(t_release-(a+d+sd+r));
    env = [env, env4];

end