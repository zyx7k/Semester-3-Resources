%--part(a)--%
N = 5;
td = 1;
fs = 10000;
P = zeros(1, N);
f0 = 50;

A_1 = zeros(1,N);
for k = 1 :5
    A_1(k) = 1/k;
end
xn_1 = harmonics(A_1, f0, P, td, fs);
% soundsc(xn_1);

%--part(b)--%

A_2 = zeros(1,N);
for k = 1 :5
    A_2(k) = (1/k)^2;
end
xn_2 = harmonics(A_2, f0, P, td, fs);
% soundsc(xn_2);

%--part(c)--%

N_new = [10, 15];
f_new = [100,150,200];
for k = 1:2
    A_new = zeros(1,N_new(k));
    for r = 1 : N_new(k)
        A_new(r) = 1/r;
    end
    P_new = zeros(1, N_new(k));
    for t = 1:3
       xn_c = harmonics(A_new, f_new(t), P_new, td, fs);
       % soundsc(xn_c);
    end
end

%--part(d)--%

N = 5;
f0 = 50;
P = zeros(1, N);
td = 1;
fs = 10000;
A_d1 = zeros(1,N);
for k = 1 :5
    A_d1(k) = sin(pi*k/N);
end
xn_d1 = harmonics(A_d1, f0, P, td, fs);
% soundsc(xn_d1);

A_d2 = zeros(1,N);
for k = 1 :5
    A_d2(k) = cos(pi*k/N);
end
xn_d2 = harmonics(A_d2, f0, P, td, fs);
% soundsc(xn_d2);

A_d3 = zeros(1,N);
for k = 1 :5
    A_d3(k) = k;
end
xn_d3 = harmonics(A_d3, f0, P, td, fs);
% soundsc(xn_d3);

figure(1);

subplot(3,1,1);
plot(xn_d1(1:500));
xlabel('Sample Index');
ylabel('Amplitude');
title('A(k) = sin(pi*k/N)')

subplot(3,1,2);
plot(xn_d2(1:500));
xlabel('Sample Index');
ylabel('Amplitude');
title('A(k) = cos(pi*k/N);')

subplot(3,1,3);
plot(xn_d3(1:500));
xlabel('Sample Index');
ylabel('Amplitude');
title('A(k) = k');

sgtitle('Harmonics for different aks');