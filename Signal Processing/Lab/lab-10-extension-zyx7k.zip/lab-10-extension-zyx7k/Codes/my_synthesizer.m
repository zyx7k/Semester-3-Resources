function yn = my_synthesizer(A,F_notes,P, adsr, td_notes,fs)
% Initialize output as empty
yn = [];

% Loop over the notes
for ii = 1: length(F_notes)

    % scale a,d,sd,r so that they sum to required note duration
    time = td_notes(ii);

    % Compute the time vector and ADSR envelope for this note
    [t_env, env] = envelope(time*adsr(1), time*adsr(2), adsr(3), time*adsr(4), time*adsr(5), fs);

    % Compute the sum of harmonics for this note xt
    xt = harmonics(A, F_notes(ii), P, time, fs);

    % Modulate the sum of harmonics with the envelope
    xte= xt.*env;

    % Add the note to the sequence yn
    yn = [yn, xte];
end
end