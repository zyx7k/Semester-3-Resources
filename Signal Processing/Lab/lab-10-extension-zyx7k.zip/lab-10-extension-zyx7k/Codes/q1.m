%-----(part a)------%

fs = 10000;
A = [0.5, 0.5];
P = [0, 0];

F_1 = [350, 440];
td = 4;

xn_1 = SineSum(A, F_1, P, td, fs);

% sound(xn_1);

%-----(part a)------%

td_b1 = 0.5;
F_2 = [480, 620];
A_new = [0, 0];

b1 = SineSum(A, F_2, P, td_b1, fs);
z1 = SineSum(A_new, F_2, P, td_b1, fs);
xn_2 = [b1, z1, b1, z1, b1, z1, b1, z1];

% sound(xn_2);

%-----(part c)------%

td_b2 = 2;
F_2 = [440, 480];
A_new = [0, 0];

b2 = SineSum(A, F_2, P, td_b2, fs);
z2 = SineSum(A_new, F_2, P, td_b2, fs);
xn_3 = [b2, z2, b2, z2, b2, z2, b2, z2];

% sound(xn_3);

%-----(part d)------%

% We are very much familiar with the sounds we hear. They are pretty
% commonly used in telephonic communication like the sound of the ring
% when we are calling a person and other being the sound that we hear
% when the recepient is unable to pick up our call.

%-----(part e)------%

index = 0 : 1 : 499;
figure(1);

subplot(3,1,1);
plot(index, xn_1(1:500));
xlabel('Sample Index');
ylabel('Amplitude');
title('First Sound');

subplot(3,1,2);
plot(index, xn_2(1:500));
xlabel('Sample Index');
ylabel('Amplitude');
title('Second Sound');

subplot(3,1,3);
plot(index, xn_3(1:500));
xlabel('Sample Index');
ylabel('Amplitude');
title('Third Sound');