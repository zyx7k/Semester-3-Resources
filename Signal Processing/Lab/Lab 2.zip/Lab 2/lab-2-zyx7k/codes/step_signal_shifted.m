function [H] = step_signal_shifted(t, t0)
    if t<t0
        H = 0;
    else
        H = 1;
    end
end