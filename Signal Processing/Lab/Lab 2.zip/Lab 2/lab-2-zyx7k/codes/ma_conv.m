function moving_avg = ma_conv(data, window_size)
    % Create moving average filter kernel
    h = ones(1, window_size) / window_size;
    
    % Apply convolution
    moving_avg = conv(data, h, 'full');
end