function output_signal = upsampler_linear(input_signal, upsample_factor)
    original_length = length(input_signal);
    
    % Initialize the output signal with zeros
    output_length = original_length * upsample_factor;
    output_signal = zeros(1, output_length);
    
    % Linear interpolation
    for i = 1:original_length
        output_signal((i-1)*upsample_factor + 1) = input_signal(i); % Copy original sample
        
        if i < original_length
            % Linear interpolation between two consecutive samples
            delta = (input_signal(i + 1) - input_signal(i)) / upsample_factor;
            for j = 1:(upsample_factor - 1)
                output_signal((i-1)*upsample_factor + j + 1) = input_signal(i) + j * delta;
            end
        end
    end
end
