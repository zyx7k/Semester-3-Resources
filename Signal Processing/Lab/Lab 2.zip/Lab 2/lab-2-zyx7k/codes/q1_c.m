n = 1:101;% Time index
new_n = 1: 105;
load('q1.mat');

N = 50;
x=x';
original_signal = x;
extra = [0 0 0 0];
x = [original_signal, extra];
movingAvg = moving_average(x, N);

subplot(2,1,1);
stem(n, original_signal); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Original Signal');
 
subplot(2,1,2);
stem(new_n, movingAvg); grid on;
xlabel('Time Index (n)');
ylabel('Moving Average');
title(['Moving Average over ', num2str(N), ' Samples']);

sgtitle('Moving Average System');

grid on;
