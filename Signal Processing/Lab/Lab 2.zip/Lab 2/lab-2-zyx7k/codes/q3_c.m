n = -10 : 110;
size_of_n = length(n);
input_signal = zeros(1, size_of_n+1);

u_n = zeros(1, size_of_n+1);
u_n_100 = zeros(1, size_of_n+1);
for k = 1: size_of_n
   u_n(k) = unit_step_function(k-11);
   u_n_100(k) = step_signal_shifted(k-11, 100);
end

for k = 1: size_of_n
    input_signal(k) = sin(pi*(k-11)/25)*(u_n(k)-u_n_100(k));
end

output_signal = dig_diff(input_signal);
n_plot = -10 : 111;

subplot(2,1,1);
stem(n_plot, input_signal); grid on;
xlabel('Time Index (n)');
xlim([0, 100]);
ylabel('Value');
title('Input Signal');

subplot(2,1,2);
stem(n_plot, output_signal); grid on;
xlabel('Time Index (n)');
xlim([0, 100]);
ylabel('Value');
title('Output Signal');

sgtitle('Digital Differentiator System');






