N = 5;

n = -5:20; % Time index
y = zeros(1, length(n)+N-1); % Example signal
original_signal = zeros(1, length(n));

for k = 0:20
    y(k+6) = unit_step_function(k);
    original_signal(k+6)  = unit_step_function(k);
end

movingAvg = moving_average(y, N);

subplot(2,1,1);
stem(n, original_signal); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Original Signal');

new_n = -5:24;
subplot(2,1,2);
stem(new_n, movingAvg); grid on;
xlabel('Time Index (n)');
ylabel('Moving Average');
title(['Moving Average over ', num2str(N), ' Samples']);

sgtitle('Moving Average System');

grid on;
