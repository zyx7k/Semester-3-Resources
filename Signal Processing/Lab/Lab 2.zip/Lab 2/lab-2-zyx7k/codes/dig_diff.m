function [output_signal] = dig_diff(input_signal)
    size_of_signal = length(input_signal);
    delayed_signal = zeros(1, size_of_signal);
    output_signal = zeros(1, size_of_signal);
    delayed_signal(1)=0;
    for k = 2 : size_of_signal
        delayed_signal(k) = input_signal(k-1);
    end
    for k = 1 : size_of_signal
        output_signal(k) = input_signal(k) - delayed_signal(k);
    end
end
