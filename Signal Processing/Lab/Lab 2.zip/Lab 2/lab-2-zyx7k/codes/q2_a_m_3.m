upsample_factor = 3; % Upsampling factor of 3: Two samples are inserted

n = 1 : 10;
new_n = 1: 10 * upsample_factor;

input_signal = zeros(1, length(n));
for k = 1 : 10
    input_signal(k) = 5 - abs(5-k);
end

%For FACTOR = 3 -->
output_signal_linear = upsampler_linear(input_signal, upsample_factor);
output_signal_zero_order = upsampler_zero_order(input_signal, upsample_factor);

subplot(1,3,1);
stem(n, input_signal); grid on;
xlabel('Time Index (n)');
ylabel('Signal');
title('Original Signal');

subplot(1,3,2);
stem(new_n, output_signal_zero_order); grid on;
xlabel('Time Index (n)');
ylabel('Signal');
title('Zero-Order Upsampling');

subplot(1,3,3);
stem(new_n, output_signal_linear); grid on;
xlabel('Time Index (n)');
ylabel('Signal');
title('Linear Upsampling');

sgtitle('Upsampling Demonstration with Upscaling Factor = 3');