n = 1 : 101;
load('q1.mat')

sample_size = 5;

moving_avg = ma_conv(x , sample_size);

subplot(2,1,1);
stem(n, x); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Original Signal');

new_n = 1: 101+sample_size-1;

subplot(2,1,2);
stem(new_n, moving_avg); grid on;
xlabel('Time Index (n)');
ylabel('Moving Average');
title(['Moving Average over ', num2str(sample_size), ' Samples']);

sgtitle('Moving Average System');

grid on;
