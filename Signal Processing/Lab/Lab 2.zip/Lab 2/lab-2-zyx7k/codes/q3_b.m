n = 0 : 20;
size_of_n = length(n);
input_signal = zeros(1, size_of_n+1);

u_n = zeros(1, size_of_n+1);
u_n_20 = zeros(1, size_of_n+1);
u_n_10 = zeros(1, size_of_n+1);
for k = 1: size_of_n
   u_n(k) = unit_step_function(k-1);
   u_n_20(k) = step_signal_shifted(k-1, 20);
   u_n_10(k) = step_signal_shifted(k-1, 10);
end

for k = 1: size_of_n
    input_signal(k) = (k * (u_n(k)-u_n_10(k)))+(20-k)*(u_n_10(k)-u_n_20(k));
end

output_signal = dig_diff(input_signal);
n_plot = 1 : 22;

subplot(2,1,1);
stem(n_plot, input_signal); grid on;
xlabel('Time Index (n)');
xlim([1, 20]);
ylabel('Value');
title('Input Signal');

subplot(2,1,2);
stem(n_plot, output_signal); grid on;
xlabel('Time Index (n)');
xlim([1, 20]);
ylabel('Value');
title('Output Signal');

sgtitle('Digital Differentiator System');
