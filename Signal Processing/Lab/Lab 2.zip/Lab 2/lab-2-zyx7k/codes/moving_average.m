function ma_array = moving_average(input_signal, N)
    accumulator = 0;
    ma_array = zeros(1, length(input_signal));

    for k = 1 : length(input_signal)
        accumulator = accumulator + input_signal(k);
        ma_array(k) = accumulator/N;
        if k >= N
            accumulator = accumulator - input_signal(k-N+1);
        end
    end
end

