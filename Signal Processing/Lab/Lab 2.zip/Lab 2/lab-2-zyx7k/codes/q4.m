alpha = -1;
beta = 0.9;
a=[1 alpha beta];
b= 1;

h = impz(b, a, 101);
n = 0 : 100;
stem(n, h); grid on;
xlabel('Time Index (n)');
ylabel('Digital Differentiation');