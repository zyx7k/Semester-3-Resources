n = -10:10;
y = zeros(size(n));
y(11) = 1;

sample_size = 5;

moving_avg = ma_conv(y, sample_size);

subplot(2,1,1);
stem(n, y); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Original Signal');

new_n = -10: 10+sample_size-1;

subplot(2,1,2);
stem(new_n, moving_avg); grid on;
xlabel('Time Index (n)');
ylabel('Moving Average');
title(['Moving Average over ', num2str(sample_size), ' Samples']);

sgtitle('Moving Average System');

grid on;
