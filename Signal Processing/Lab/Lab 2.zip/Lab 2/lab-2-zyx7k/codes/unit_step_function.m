function [H] = unit_step_function(t)
    if t<0
        H = 0;
    else
        H = 1;
    end
end