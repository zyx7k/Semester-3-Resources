function output_signal = upsampler_zero_order(input_signal, upsample_factor)
    original_length = length(input_signal);
    
    % Initialize the output signal with zeros
    output_length = original_length * upsample_factor;
    output_signal = zeros(1, output_length);
    
    % Linear interpolation
    for i = 1:original_length
        output_signal((i-1)*upsample_factor + 1) = input_signal(i); % Copy original sample
        
        if i < original_length
            for j = 1:(upsample_factor - 1)
                output_signal((i-1)*upsample_factor + j + 1) = 0;
            end
        end
    end
end
