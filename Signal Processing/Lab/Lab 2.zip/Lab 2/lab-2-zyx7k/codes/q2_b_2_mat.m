load('q2_2.mat');  % Load variables from q2_2.mat
upsample_factor = 2; % Upsampling factor of 2: One sample is inserted

n = 1 : 101;
new_n = 1: 101 * upsample_factor;

%For FACTOR = 2 -->
output_signal_linear = upsampler_linear(x, upsample_factor);
output_signal_zero_order = upsampler_zero_order(x, upsample_factor);

desired_ticks = 0:5:205;

subplot(2,1,1);
stem(new_n, output_signal_zero_order); grid on;
xlim([0, 205]);
xticks(desired_ticks);
xlabel('Time Index (n)');
ylabel('Signal');
title('Zero-Order Upsampling');

subplot(2,1,2);
stem(new_n, output_signal_linear); grid on;
xlim([1, 205]);
xticks(desired_ticks);
xlabel('Time Index (n)');
ylabel('Value');
title('Linear Upsampling');

sgtitle('Upsampling Demonstration of "q2(2).mat" with Upscaling Factor = 2');