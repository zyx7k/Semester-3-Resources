function moving_avg = moving_average_conv(x, M)
    h = ones(1, M) / M;
    moving_avg = conv(x, h, 'full');
end