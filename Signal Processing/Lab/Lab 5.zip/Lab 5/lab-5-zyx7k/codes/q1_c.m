w = -10:0.01:10;
N0 =1;
n = 1:101;

%-----------First Signal-----------%

b = 0.01;
x1_posb = zeros(1,101);
x1_negb = zeros(1,101);
for k = 1 : 101
    x1_posb(k) = (b)^(k-N0);
end
for k = 1 : 101
    x1_negb(k) = (-b)^(k-N0);
end

X1_posb = DT_Fourier(x1_posb, N0, w);
X1_negb = DT_Fourier(x1_negb, N0, w);

figure(1);
subplot(2, 2, 1);
plot(n, x1_posb, '-r'); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Plot of Signal for a = b');

subplot(2, 2, 2);
plot(n, x1_negb, '-b'); grid on;
xlabel('Time Index [n]');
ylabel('Magnitude');
title('Plot of Signal for a = -b');

subplot(2, 2, 3);
plot(w, abs(X1_posb), '-g'); grid on;
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('Magnitude Plot for a = b');

subplot(2, 2, 4);
plot(w, abs(X1_negb)); grid on;
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('Magnitude Plot for a = -b');

sgtitle('Plots for b = 0.01');

%-----------Second Signal-----------%

b = 0.5;
x2_posb = zeros(1,101);
x2_negb = zeros(1,101);
for k = 1 : 101
    x2_posb(k) = (b)^(k-N0);
end
for k = 1 : 101
    x2_negb(k) = (-b)^(k-N0);
end

X2_posb = DT_Fourier(x2_posb, N0, w);
X2_negb = DT_Fourier(x2_negb, N0, w);

figure(2);
subplot(2, 2, 1);
plot(n, x2_posb, '-r'); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Plot of Signal for a = b');

subplot(2, 2, 2);
plot(n, x2_negb, '-b'); grid on;
xlabel('Time Index [n]');
ylabel('Magnitude');
title('Plot of Signal for a = -b');

subplot(2, 2, 3);
plot(w, abs(X2_posb), '-g'); grid on;
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('Magnitude Plot for a = b');

subplot(2, 2, 4);
plot(w, abs(X2_negb)); grid on;
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('Magnitude Plot for a = -b');

sgtitle('Plots for b = 0.5');

%-----------Third Signal-----------%

b = 0.99;
x3_posb = zeros(1,101);
x3_negb = zeros(1,101);
for k = 1 : 101
    x3_posb(k) = (b)^(k-N0);
end
for k = 1 : 101
    x3_negb(k) = (-b)^(k-N0);
end

X3_posb = DT_Fourier(x3_posb, N0, w);
X3_negb = DT_Fourier(x3_negb, N0, w);

figure(3);
subplot(2, 2, 1);
plot(n, x3_posb, '-r'); grid on;
xlabel('Time Index [n]');
ylabel('Magntiude');
title('Plot of Signal for a = b');

subplot(2, 2, 2);
plot(n, x3_negb, '-b'); grid on;
xlabel('Time Index [n]');
ylabel('Magnitude');
title('Plot of Signal for a = -b');

subplot(2, 2, 3);
plot(w, abs(X3_posb), '-g'); grid on;
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('Magnitude Plot for a = b');

subplot(2, 2, 4);
plot(w, abs(X3_negb)); grid on;
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('Magnitude Plot for a = -b');

sgtitle('Plots for b = 0.99');

