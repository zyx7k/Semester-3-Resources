time_index = -100 : 100;

w1 = pi/8;
w2 = pi/4;

syms w;
X = piecewise(-pi < w < w1, 0, w1 <= w <= w2, 1, w2 < w < pi, 0);

xn = zeros(1, length(time_index));
for k = 1 : length(time_index)
    n = k - 101;
    sig = X * exp(1j * w * n);
    xn(k) = int(sig, w, -pi, pi)/(2*pi);
end

figure(1);
subplot(1,2,1);
plot(time_index, real(xn)); grid on;
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Real Part of x[n]')

subplot(1,2,2);
plot(time_index, imag(xn)); grid on;
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Imaginary Part of x[n]')

sgtitle('Plot for wc = \pi / 6 for given band-pass signal');
