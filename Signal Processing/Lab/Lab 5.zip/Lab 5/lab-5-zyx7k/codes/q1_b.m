w = -10:0.01:10;

%-----------First Signal-----------%
x1 = [1];
N0 = 1;
X1 = DT_Fourier(x1, N0, w);

figure(1);
subplot(2, 2, 1);
plot(w, abs(X1), '-r'); grid on;
xlabel('Frequency (\omega)');
ylabel('Magntiude');
title('Magnitude Plot');

subplot(2, 2, 2);
plot(w, angle(X1), '-b'); grid on;
xlabel('Frequency (\omega)');
ylabel('Phase');
title('Phase Plot');

subplot(2, 2, 3);
plot(w, real(X1), '-g'); grid on;
xlabel('Frequency (\omega)');
ylabel('Real Part');
title('Real Part Plot');

subplot(2, 2, 4);
plot(w, imag(X1)); grid on;
xlabel('Frequency (\omega)');
ylabel('Imaginary Part');
title('Imaginary Part Plot');

sgtitle('Plots for Unit Impulse Function');

%-----------Second Signal-----------%

figure(2);
x2 = [1];
N0 = 4;
X2 = DT_Fourier(x2, N0, w);

subplot(2, 2, 1);
plot(w, abs(X2), '-r'); grid on;
xlabel('Frequency (\omega)');
ylabel('Magntiude');
title('Magnitude Plot');

subplot(2, 2, 2);
plot(w, angle(X2), '-b'); grid on;
xlabel('Frequency (\omega)');
ylabel('Phase');
title('Phase Plot');

subplot(2, 2, 3);
plot(w, real(X2), '-g'); grid on;
xlabel('Frequency (\omega)');
ylabel('Real Part');
title('Real Part Plot');

subplot(2, 2, 4);
plot(w, imag(X2)); grid on;
xlabel('Frequency (\omega)');
ylabel('Imaginary Part');
title('Imaginary Part Plot');

sgtitle('Plots for Shifted Unit Impulse Function');

%-----------Third Signal-----------%

figure(3);
x3 = ones(1, 7);
N0 = 4;
X3 = DT_Fourier(x3, N0, w);

subplot(2, 2, 1);
plot(w, abs(X3), '-r'); grid on;
xlabel('Frequency (\omega)');
ylabel('Magntiude');
title('Magnitude Plot');

subplot(2, 2, 2);
plot(w, angle(X3), '-b'); grid on;
xlabel('Frequency (\omega)');
ylabel('Phase');
title('Phase Plot');

subplot(2, 2, 3);
plot(w, real(X3), '-g'); grid on;
xlabel('Frequency (\omega)');
ylabel('Real Part');
title('Real Part Plot');

subplot(2, 2, 4);
plot(w, imag(X3)); grid on;
xlabel('Frequency (\omega)');
ylabel('Imaginary Part');
title('Imaginary Part Plot');

sgtitle('Plots for Rectangular Pulse from -3 to 3');

%-----------Fourth Signal-----------%

figure(4);
x4 = zeros(1, 401);
N0 = 201;
for k = 1: 401
    x4(k) = sin(pi/4 * (k-N0));
end
X4 = DT_Fourier(x4, N0, w);

subplot(2, 2, 1);
plot(w, abs(X4), '-r'); grid on;
xlabel('Frequency (\omega)');
ylabel('Magntiude');
title('Magnitude Plot');

subplot(2, 2, 2);
plot(w, angle(X4), '-b'); grid on;
xlabel('Frequency (\omega)');
ylabel('Phase');
title('Phase Plot');

subplot(2, 2, 3);
plot(w, real(X4), '-g'); grid on;
xlabel('Frequency (\omega)');
ylabel('Real Part');
title('Real Part Plot');

subplot(2, 2, 4);
plot(w, imag(X4)); grid on;
xlabel('Frequency (\omega)');
ylabel('Imaginary Part');
title('Imaginary Part Plot');

sgtitle('Plots for Finite Duration Sinusoid');
