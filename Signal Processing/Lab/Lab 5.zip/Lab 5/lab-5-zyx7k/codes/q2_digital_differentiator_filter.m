%---------------------(g)-------------------

%The Simple Digital Differentiator Filter has been implemented
%with the help of the function script: digital_differentiator.m

%SCRIPT TO GENERATE SINE WAVE AND IT'S NOISY VERSION

w0 = pi /200;
n = 0 : 1000;
len_x = length(n);

xn = zeros(1, len_x);
sn = zeros(1, len_x);
vn = randn(1, len_x);
for k = 1 : length(n)
    sn(k) = 5 * sin(w0*n(k));
    xn(k) = sn(k) + vn(k);
end

figure(1);
subplot(2,2,1);
plot(n, xn, '-y'); grid('on');
hold on
plot(n, sn, '-r');
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Sine Wave and its Noisy Version');
legend('x[n]', 's[n]');

filtered_signal = digital_differentiator(xn);

subplot(2,2,2);
plot(sn); grid('on');
hold on
plot(filtered_signal);
xlim([0,1010]);
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Original Signal and its filtered version');
legend('s[n]', 'y[n]');

w = -10:0.01:10;
N0 = 1;
xn_dtft = DT_Fourier(xn, N0, w);
filtered_dtft = DT_Fourier(filtered_signal, N0, w);

subplot(2,2,3);
plot(w, abs(xn_dtft)); grid('on');
xlabel('Time Index [n]');
ylabel('Magnitude');
title('DTFT of Noisy Signal x[n]');

subplot(2,2,4);
plot(w, abs(filtered_dtft)); grid('on');
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('DTFT of Filtered Signal');