%b) The Order-M moving Average Filter using conv() has
%been implemented in the function script: moving_average_conv.m

%c) SCRIPT TO GENERATE SINE WAVE AND IT'S NOISY VERSION
%We'll demonstrate Moving Average on it for different values of M.

w0 = pi /200;
n = 0 : 1000;
len_x = length(n);

xn = zeros(1, len_x);
sn = zeros(1, len_x);
vn = randn(1, len_x);
for k = 1 : length(n)
    sn(k) = 5 * sin(w0*n(k));
    xn(k) = sn(k) + vn(k);
end

figure(1);
subplot(2,2,1);
plot(n, xn, '-y'); grid('on');
hold on
plot(n, sn, '-r');
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Sine Wave and its Noisy Version');
legend('x[n]', 's[n]');

%---------------------(d)-------------------

M = 5;
yn_1 = moving_average_conv(xn, M);

subplot(2,2,2);
grid('on');
plot(sn);
hold on
plot(yn_1);
xlabel('Time Index [n]');
ylabel('Amplitude');
title('M = 5');
legend('s[n]', 'y[n]');

M = 21;
yn_2 = moving_average_conv(xn, M);

subplot(2,2,3);
grid('on');
plot(sn);
hold on
plot(yn_2);
xlabel('Time Index [n]');
ylabel('Amplitude');
title('M = 21');
legend('s[n]', 'y[n]');

M = 51;
yn_3 = moving_average_conv(xn, M);

subplot(2,2,4);
grid('on');
plot(sn);
hold on
plot(yn_3);
xlabel('Time Index [n]');
ylabel('Amplitude');
title('M = 51');
legend('s[n]', 'y[n]');
sgtitle('Moving Average Filter Output for different values of M');

%---------------------(f)-------------------
w = -10:0.01:10;
N0 = 1;
xn_dtft = DT_Fourier(xn, N0, w);
yn_1_dtft = DT_Fourier(yn_1, N0, w);
yn_2_dtft = DT_Fourier(yn_2, N0, w);
yn_3_dtft = DT_Fourier(yn_3, N0, w);

figure(2);
subplot(2,2,1);
plot(w, abs(xn_dtft)); grid('on');
xlabel('Time Index [n]');
ylabel('Magnitude');
title('DTFT of x[n]');

subplot(2,2,2);
plot(w, abs(yn_1_dtft)); grid('on');
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('DTFT of filter output with M = 5');

subplot(2,2,3);
plot(w, abs(yn_2_dtft)); grid('on');
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('DTFT of filter output with M = 21');

subplot(2,2,4);
plot(w, abs(yn_3_dtft)); grid('on');
xlabel('Frequency (\omega)');
ylabel('Magnitude');
title('DTFT of filter output with M = 51');
sgtitle('DTFT plots for various values of M');

