clc, clearvars, close all

syms t;
xt = 2*cos(2*pi*t)+cos(6*pi*t);
T=1;
N=5;
t1 = -T/2;
t2=T/2;

vector = fourierCoeff(t, xt, T, t1, t2, N);

FS_idx = -N:N;
figure; stem(FS_idx,vector); grid on;
xlabel('Index');
ylabel('Coefficient Value');

