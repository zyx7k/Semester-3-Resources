clc, clearvars, close all

syms t;
T=1;
T1=T/4;
N=10;

xt = piecewise(-T1 <= t <= T1, 1, T1 < abs(t) < T/2, 0);
t1 = -T1;
t2 = T1;

vector = fourierCoeff(t, xt, T, t1, t2, N);

FS_idx = -N:N;
figure; stem(FS_idx,vector); grid on;
xlabel('Index');
ylabel('Coefficient Value');
