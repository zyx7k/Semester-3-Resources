function vector = fourierCoeff(t, xt, T, t1, t2, N)

    if N <= 0
        error('N must be a positive integer');
    end

    % Initialize the coefficients vector
    vector = zeros(1, 2*N+1);
    wo = 2 * pi / T;

    for k = -N:N
            sig = xt * exp(-1 * (1j) * k * wo * t);
            coeff = 1/ T * int(sig, t, t1, t2);
            vector(k+N+1)=coeff;    
    end
end