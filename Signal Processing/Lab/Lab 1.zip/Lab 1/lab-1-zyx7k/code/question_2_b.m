clc, clearvars, clear all

syms t;
xt = 2*cos(2*pi*t)+cos(6*pi*t);
T=1;
N=5;
t1 = -T/2;
t2=T/2;

time_grid_reconstructed = -0.5 : 0.05 : 0.5;
time_grid_original = -0.5 : 0.001 : 0.5;

coeff_vec = fourierCoeff(t, xt, T, t1, t2, N);

reconstructed_signal = partialfouriersum(coeff_vec, T, time_grid_reconstructed);
orign_sig = 2*cos(2*pi*time_grid_original)+cos(6*pi*time_grid_original);

plot(time_grid_original, orign_sig, 'b');
hold on;
plot(time_grid_reconstructed, real(reconstructed_signal), 'r');
xlabel('Time');
ylabel('Amplitude');
title('Original Signal vs Reconstructed Signal');
legend('Original Signal','Reconstructed Signal')
grid on;
