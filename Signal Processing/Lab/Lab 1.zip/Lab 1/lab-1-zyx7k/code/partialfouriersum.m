function sig = partialfouriersum(A, T, time_grid)
    N = (length(A)-1)/2;
    sig = zeros(size(time_grid));

    for k = -N:N
            coeff = A(k+N+1);
            w = 2 * pi / T;
            sig = sig + (coeff * exp((1j) * w * k * time_grid));
    end
end