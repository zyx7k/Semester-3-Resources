clc, clearvars, close all

syms t;
T=20;
T1=0.1;
N=10*T;
t1 = -T1;
t2 = T1;

xt = piecewise(-T1 <= t <= T1, 1, T1 < abs(t) < T/2, 0);
vector = fourierCoeff(t, xt, T, t1, t2, N);
vector = vector * T;

FS_idx = -N:N;
figure; stem(FS_idx,vector); grid on;
xlabel('Index');
ylabel('Coefficient Value');
