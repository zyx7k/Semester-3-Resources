clc;
clearvars;
clear all;

syms t;
xt = 2*cos(2*pi*t) + cos(6*pi*t);
T = 1;
N = 100;  % Increase the number of Fourier coefficients
t1 = -T/2;
t2 = T/2;
time_grid_reconstructed = -0.5 : 0.001 : 0.5; % Use finer time grid
time_grid_original = -0.5 : 0.001 : 0.5;

coeff_vec = fourierCoeff(t, xt, T, t1, t2, N);

reconstructed_signal = partialfouriersum(coeff_vec, T, time_grid_reconstructed);
orign_sig = 2*cos(2*pi*time_grid_original) + cos(6*pi*time_grid_original);

% Interpolate the reconstructed signal to match the original time grid
reconstructed_interp = interp1(time_grid_reconstructed, reconstructed_signal, time_grid_original);

absolute_differences = abs(orign_sig - reconstructed_interp);
max_absolute_error = max(absolute_differences);
rms_error = rms(orign_sig - reconstructed_interp);
fprintf('Maximum Absolute Error: %e\n', max_absolute_error);
fprintf('Root Mean Square Error: %e\n', rms_error);