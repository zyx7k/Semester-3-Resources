%------part(b)------%

w = -5 : 0.1 :5;
T_1 = 2;
syms t;
%Rectangular Pulse%
xt_1 = piecewise(-T_1 <= t <= T_1, 1);

X_1 = continuousFT(t, xt_1, -T_1, T_1, w);

figure(1);
subplot(2,2,1);
plot(w, real(X_1)); grid on;
xlabel('\w');
ylabel('Real(X)');
title('Plotting real Part of CTFT');

subplot(2,2,2);
plot(w, imag(X_1)); grid on;
xlabel('\w');
ylabel('Imag(X)');
title('Plotting imaginary Part of CTFT');

subplot(2,2,3);
plot(w, abs(X_1)); grid on;
xlabel('\w');
ylabel('Abs(X)');
title('Plotting Absolute Value of CTFT');

subplot(2,2,4);
plot(w, angle(X_1)); grid on;
xlabel('\w');
ylabel('Phase(X)');
title('Plotting Phase of CTFT');

sgtitle('CTFT of a Rectangular Pulse for T = 2');

%------part(c)------%
T_2 = 1;
syms t;
%Rectangular Pulse%
xt_2 = piecewise(-T_2 <= t <= T_2, 1);

X_2 = continuousFT(t, xt_2, -T_2, T_2, w);

figure(2);
subplot(2,2,1);
plot(w, real(X_2)); grid on;
xlabel('\w');
ylabel('Real(X)');
title('Plotting real Part of CTFT');

subplot(2,2,2);
plot(w, imag(X_2)); grid on;
xlabel('\w');
ylabel('Imag(X)');
title('Plotting imaginary Part of CTFT');

subplot(2,2,3);
plot(w, abs(X_2)); grid on;
xlabel('\w');
ylabel('Abs(X)');
title('Plotting Absolute Value of CTFT');

subplot(2,2,4);
plot(w, angle(X_2)); grid on;
xlabel('\w');
ylabel('Phase(X)');
title('Plotting Phase of CTFT');

sgtitle('CTFT of a Rectangular Pulse for T = 1');

%-------one more plot--------%

T_3 = 4;
syms t;
%Rectangular Pulse%
xt_3 = piecewise(-T_3 <= t <= T_3, 1);

X_3 = continuousFT(t, xt_3, -T_3, T_3, w);

figure(3);
subplot(2,2,1);
plot(w, real(X_3)); grid on;
xlabel('\w');
ylabel('Real(X)');
title('Plotting real Part of CTFT');

subplot(2,2,2);
plot(w, imag(X_3)); grid on;
xlabel('\w');
ylabel('Imag(X)');
title('Plotting imaginary Part of CTFT');

subplot(2,2,3);
plot(w, abs(X_3)); grid on;
xlabel('\w');
ylabel('Abs(X)');
title('Plotting Absolute Value of CTFT');

subplot(2,2,4);
plot(w, angle(X_3)); grid on;
xlabel('\w');
ylabel('Phase(X)');
title('Plotting Phase of CTFT');

sgtitle('CTFT of a Rectangular Pulse for T = 4');

%------part(d-1)------%

T_4 = pi;
syms t;
xt_4 = piecewise(-T_4 <= t <= T_4, exp(1j*t));

X_4 = continuousFT(t, xt_4, -T_4, T_4, w);

figure(4);
subplot(2,2,1);
plot(w, real(X_4)); grid on;
xlabel('\w');
ylabel('Real(X)');
title('Plotting real Part of CTFT');

subplot(2,2,2);
plot(w, imag(X_4)); grid on;
xlabel('\w');
ylabel('Imag(X)');
title('Plotting imaginary Part of CTFT');

subplot(2,2,3);
plot(w, abs(X_4)); grid on;
xlabel('\w');
ylabel('abs(X)');
title('Plotting Absolute Value of CTFT');

subplot(2,2,4);
plot(w, angle(X_4)); grid on;
xlabel('\w');
ylabel('Phase(X)');
title('Plotting Phase of CTFT');

sgtitle('CTFT of a exp(j*t) for T = pi');


%------part(d-2)------%

T_5 = pi;
syms t;
%Rectangular Pulse%
xt_5 = piecewise(-T_5 <= t <= T_5, cos(t));

X_5 = continuousFT(t, xt_5, -T_5, T_5, w);

figure(5);
subplot(2,2,1);
plot(w, real(X_5)); grid on;
xlabel('\w');
ylabel('Real(X)');
title('Plotting real Part of CTFT');

subplot(2,2,2);
plot(w, imag(X_5)); grid on;
xlabel('\w');
ylabel('Imag(X)');
title('Plotting imaginary Part of CTFT');

subplot(2,2,3);
plot(w, abs(X_5)); grid on;
xlabel('\w');
ylabel('Abs(X)');
title('Plotting Absolute Value of CTFT');

subplot(2,2,4);
plot(w, angle(X_5)); grid on;
xlabel('\w');
ylabel('Phase(X)');
title('Plotting Phase of CTFT');

sgtitle('CTFT of cos(t) for T = pi');

%------part(e)------%

T_6 = 1;
syms t;
%Rectangular Pulse%
xt_6 = piecewise(-T_6 <= t < T_6, 1-abs(t));

X_6 = continuousFT(t, xt_6, -T_6, T_6, w);

figure(6);
subplot(2,2,1);
plot(w, real(X_6)); grid on;
xlabel('\w');
ylabel('Real(X)');
title('Plotting real Part of CTFT');

subplot(2,2,2);
plot(w, imag(X_6)); grid on;
xlabel('\w');
ylabel('Imag(X)');
title('Plotting imaginary Part of CTFT');

subplot(2,2,3);
plot(w, abs(X_6)); grid on;
xlabel('\w');
ylabel('Abs(X)');
title('Plotting Absolute Value of CTFT');

subplot(2,2,4);
plot(w, angle(X_6)); grid on;
xlabel('\w');
ylabel('Phase(X)');
title('Plotting Phase of CTFT');

sgtitle('CTFT of triangular pulse for T = 1');
