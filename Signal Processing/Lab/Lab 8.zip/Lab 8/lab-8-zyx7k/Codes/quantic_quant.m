function Y = quantic_quant(x,B,a)
 Y = zeros(size(x));
 quantizer_levels = 2^B;
 interval = linspace(-a,a,quantizer_levels);
 for i = 1:length(x)
     for j = 1:(quantizer_levels-1)
         if x(i)>=interval(j) && x(i)<=interval(j+1)
             Y(i) = ((interval(j) + interval(j+1))/2);
             break;
         end
     end
 end
end


