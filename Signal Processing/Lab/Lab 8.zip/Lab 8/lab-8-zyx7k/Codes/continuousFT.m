function  X = continuousFT(t,xt,a,b,w)
    X = zeros(1, length(w));
    for k = 1 : length(w)
        signal = xt* exp(-1j*w(k)*t);
        X(k) = int(signal, t, a, b);
    end
end