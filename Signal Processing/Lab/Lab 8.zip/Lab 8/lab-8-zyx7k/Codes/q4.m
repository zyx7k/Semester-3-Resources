filename = 'file_example_WAV_1MG.wav';
[y,Fs] = audioread(filename);
%%%%%%%(part-1)%%%%%%%
B = 3;
a = 1;
y_q = quantic_quant(y,B,a);
sound(y,Fs);
pause(length(y)/Fs);
sound(y_q,Fs);

%%%%%%%(part-2)%%%%%%
a = 1;
B = [1,2,3,4,5,6,7,8];
for i = 1:length(B)
   y_q = quantic_quant(y,B(i),a);
   sound(y_q,Fs);
   pause(2);
end