f0 = 5; % 10kHz
syms t;

% Symbolic expression
x_t = sin(2*pi*f0*t);

Fs = 4;
time_index = 0 : 1/Fs : 1;

x_n = zeros(1, length(time_index));

for k = 1 : length(time_index)
    % Evaluate the symbolic expression at the specific time_index value
    x_n(k) = subs(x_t, t, time_index(k));
end

disp(x_n);
