f0 = 10;
Fs = 5000;
time_index = 0 : 1/Fs : 1;

x_n = sin(2*pi*f0*time_index); %Input Signal
a = 1;
B = 4;
xq_n_4 = quadratic_quant(x_n, B, a); 

figure(1);
subplot(3,1,1);
plot(time_index, x_n);
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Sampled Signal');

subplot(3,1,2);
plot(time_index, xq_n_4);
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Quantized Signal');

%Quantization Error:

eq_n_4 = x_n - xq_n_4;
subplot(3,1,3);
plot(time_index, eq_n_4);
xlabel('Time Index [n]');
ylabel('Amplitude');
title('Quantization Error');


figure(2);
subplot(2,1,1);
histogram(eq_n_4, 15);
title('Histogram for B = 4');

B = 3;
xq_n_3 = quadratic_quant(x_n, B, a);
eq_n_3 = x_n - xq_n_3;
subplot(2,1,2);
histogram(eq_n_3, 15);
title('Histogram for B = 3');

B = 1;
xq_n_1 = quadratic_quant(x_n, B, a);
eq_n_1 = x_n - xq_n_1;

B = 2;
xq_n_2 = quadratic_quant(x_n, B, a);
eq_n_2 = x_n - xq_n_2;

B = 5;
xq_n_5 = quadratic_quant(x_n, B, a);
eq_n_5 = x_n - xq_n_5;

B = 6;
xq_n_6 = quadratic_quant(x_n, B, a);
eq_n_6 = x_n - xq_n_6;

B = 7;
xq_n_7 = quadratic_quant(x_n, B, a);
eq_n_7 = x_n - xq_n_7;

B = 8;
xq_n_8 = quadratic_quant(x_n, B, a);
eq_n_8 = x_n - xq_n_8;

figure(3);

error_array = zeros(1,8);
for k = 1 : 8
    str1 = 'eq_n_';
    str2 = num2str(k);
    string = [str1, str2];
    error_array(k) = max(abs(eval(string)));
end
x_axis_index = 1 : 8;
stem(x_axis_index, error_array);
xlabel('B (Number of Bits)');
ylabel('Maximum Absolute Quantization Error');
title('Maximum Absolute Quantization Error vs. B');

%SQNR Calculation
sum_1 = 0;

value_array = [];

x_n = x_n.^2;
Nr = sum(x_n);

for k = 1:8
    str1 = 'eq_n_';
    str2 = num2str(k);
    string = [str1, str2];
    arr = eval(string).^2;
    Dr = sum(arr);
    value_array = [value_array,  Nr/Dr];
end


figure(4);
stem(x_axis_index, value_array);
xlabel('B (Number of Bits)');
ylabel('SQNR (dB)');
title('SQNR vs. B plot');