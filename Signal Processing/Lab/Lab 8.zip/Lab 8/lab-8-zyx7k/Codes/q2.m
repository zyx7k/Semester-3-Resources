a = 1/2;  
n = 0:255;  
signal = (a.^n); 
output = radix2fft(signal);
figure;
subplot(2,1,1);
stem(n, output);
title('Fast Fourier Transform (Radix-2)');
xlabel('k');
ylabel('X(k)');
xlim([0,255]);

output2 = fft(signal);
subplot(2,1,2);
stem(n, output2);
title('Fast Fourier Transform using fft');
xlabel('k');
ylabel('X(k)');
xlim([0,255]);
