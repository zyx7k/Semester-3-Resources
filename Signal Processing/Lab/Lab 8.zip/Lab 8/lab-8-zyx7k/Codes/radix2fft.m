function X = radix2fft(x)

    N = length(x);
    X = zeros(1,N);
    if(N==2)
        X(1) = x(1)+x(2);
        X(2) = x(1)-x(2);
    else
        X1 = radix2fft(x(1:2:end));
        X2 = radix2fft(x(2:2:end));

        for k = 1 : N/2
            X(k) = X1(k) + exp((-1i*2*pi*(k-1))/N)*X2(k);
            X(k+(N/2)) = X1(k) - exp((-1i*2*pi*(k-1))/N)*X2(k);
        end
    end 
end