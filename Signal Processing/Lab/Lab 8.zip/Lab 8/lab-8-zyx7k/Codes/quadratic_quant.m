function y = quadratic_quant(x, B, a)
    N = length(x);  
    y = zeros(1, N);
    
    number_of_intervals = 2^(B-1);
    intervals = linspace(0, 1, number_of_intervals+1);
    second_interval = a*intervals.^2;
    first_interval = flip(-a*intervals.^2);
    range = [first_interval(1:end-1), second_interval];

    for k = 1: N
        value = x(k);
        for o = 1 : (2^B)
            lower_limit = range(o);
            upper_limit = range(o+1);
            if(value >= lower_limit && value < upper_limit)
      
                y(k) = (lower_limit+upper_limit)/2;
                break

            elseif(value < lower_limit)
                y(k) = range(0);

            elseif(value>=upper_limit)
                y(k) = range(end);
       
            end
        end
    end
end