range_signal_1 = 1:10;
signal_1 = ones(1, length(range_signal_1));
range_signal_2 = 0: 9;
signal_2 = zeros(1,length(range_signal_2));

for k = 1:10
    signal_2(k)=randi([-5,5]);
end

conv_signal = convolution_function(signal_1, signal_2);
plot_range = range_signal_1(1)+range_signal_2(1) : range_signal_2(end)+range_signal_1(end);

subplot(3,1,1);
stem(range_signal_1, signal_1); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Signal 1');

subplot(3,1,2);
stem(range_signal_2, signal_2); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Signal 2');

subplot(3,1,3);
stem(plot_range, conv_signal); grid on;
xlim([1, 19]);
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Convolution Result');