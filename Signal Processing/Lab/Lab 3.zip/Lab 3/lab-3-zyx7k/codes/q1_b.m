range_signal_1 = 0 : 3;
signal_1 = ones(1, length(range_signal_1));

conv_1 = conv(signal_1, signal_1, 'full');
range_conv_1 = range_signal_1(1)+range_signal_1(1) : range_signal_1(end)+range_signal_1(end);

conv_2 = conv(conv_1, signal_1, 'full');
range_conv_2 = range_signal_1(1)+range_conv_1(1) : range_signal_1(end) + range_conv_1(end);

conv_3 = conv(conv_2, signal_1, 'full');
range_conv_3 = range_signal_1(1)+range_conv_2(1) : range_signal_1(end) + range_conv_2(end);

conv_4 = conv(conv_3, signal_1, 'full');
range_conv_4 = range_signal_1(1)+range_conv_3(1) : range_signal_1(end) + range_conv_3(end);

subplot(2,2,1);
stem(range_conv_1, conv_1); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('First Convolution');

subplot(2,2,2);
stem(range_conv_2, conv_2); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Second Convolution');

subplot(2,2,3);
stem(range_conv_3, conv_3); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Third Convolution');

subplot(2,2,4);
stem(range_conv_4, conv_4); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Fourth Convolution');