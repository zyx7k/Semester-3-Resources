function [conv_signal] = convolution_function(signal_1, signal_2)
    len_sig_1 = length(signal_1);
    len_sig_2 = length(signal_2);
    conv_length = len_sig_1 + len_sig_2 - 1;
    conv_signal = zeros(1, conv_length);

    signal_1_rev = flip(signal_1);

    % Performing the convolution of the signals now:
    for k = 1:conv_length
        value = 0;
        for m = max(1, k - len_sig_2 + 1):min(len_sig_1, k)
            value = value + signal_2(k - m + 1) * signal_1_rev(m);
        end
        conv_signal(k) = value;
    end
end
