range_signal_1 = -5:5;
len_sig_1 = length(range_signal_1);
signal_1 = zeros(1, len_sig_1);
for k = 1: len_sig_1
    signal_1(k) = (-1)^range_signal_1(k);
end

range_signal_2 = -3:1;
len_sig_2 = length(range_signal_2);
signal_2 = ones(1, len_sig_2);

conv_sig = conv(signal_1, signal_2, 'full');
range_conv_sig = range_signal_1(1)+range_signal_2(1) : range_signal_2(end) + range_signal_1(end);

subplot(3,1,1);
stem(range_signal_1, signal_1); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Signal 1');

subplot(3,1,2);
stem(range_signal_2, signal_2); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Signal 2');

subplot(3,1, 3);
stem(range_conv_sig, conv_sig); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Convolution of both signals');