% 3.2 Part a)

%Defining x1[n]
x1_range = 1: 10;
sequence_length = 10;
mu = 1;         % Mean
sigma = 2;      % Standard deviation

x1 = mu + sigma * randn(1, sequence_length);

%Defining x2[n]
x2_range = 0:9;
x2 = zeros(1, 10);
x2(4)=1;

% 3.2 Part b)
conv_linear = conv(x1, x2, 'full'); %performing linear convolution
%Using 'full' helps us get convolution of expected length i.e.
%len(x1)+len(x2)-1

conv_circular = conv(x1, x2); %performing circular convolution
%ccnov gives expected length by default.


% 3.2 Part c)
plot_range = 1: 19;

subplot(2,2, 1);
stem(x1_range, x1); grid on;
xlabel("Time Index");
ylabel("Value");
title("Random Gaussian Sequence");

subplot(2,2, 2);
stem(x2_range, x2); grid on;
xlabel("Time Index");
ylabel("Value");
title("Dirac-Delta Signal");

subplot(2,2, 3);
stem(plot_range, conv_linear); grid on;
xlabel("Time Index");
ylabel("Value");
title("Linear Convolution Result");

subplot(2,2, 4);
stem(plot_range, conv_circular); grid on;
xlabel("Time Index");
ylabel("Value");
title("Circular Convolution Result");