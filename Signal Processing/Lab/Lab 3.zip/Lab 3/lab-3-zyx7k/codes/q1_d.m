f = 0.05; 
w = 2*pi*f;

range_signal_1 = 0:20;
len_sig_1 = length(range_signal_1);
signal_1 = zeros(1, len_sig_1);
for k = 1: len_sig_1
    signal_1(k) = sin(w *range_signal_1(k));
end

range_signal_2 = -18:14;
len_sig_2 = length(range_signal_2);
signal_2 = zeros(1, len_sig_2);
for k = 1: len_sig_2
    signal_2(k) = (-1)^range_signal_2(k);
end

conv_sig = conv(signal_1, signal_2, 'full');
range_conv_sig = range_signal_1(1)+range_signal_2(1) : range_signal_2(end) + range_signal_1(end);

subplot(3,1,1);
stem(range_signal_1, signal_1); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Signal 1');

subplot(3,1,2);
stem(range_signal_2, signal_2); grid on;
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Signal 2');

subplot(3,1, 3);
stem(range_conv_sig, conv_sig); grid on;
xlim([-18, 34]);
desired_xticks = linspace(-18, 34, 27);
set(gca, 'XTick', desired_xticks);
xticklabels(desired_xticks);
xlabel('Time Index (n)');
ylabel('Signal y[n]');
title('Convolution of both signals');